const button = document.querySelector('.btn button'); // Use querySelector

button.addEventListener('click', function() {
  // Redirect to next.html
  window.location.href = 'next.html'; 
});